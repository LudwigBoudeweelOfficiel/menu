<!DOCTYPE html>
<html>
<head>
  <title>Formulaire PDF</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.68/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.68/vfs_fonts.js"></script>
</head>
<body>
  <div>
    <h1>Formulaire PDF</h1>
    <div>
      <label for="text-input">Saisissez votre texte :</label>
      <input id="text-input" type="text" oninput="updatePreview()" />
    </div>
    <div>
      <h2>Aperçu du PDF :</h2>
      <iframe id="pdf-preview" width="500" height="600"></iframe>
    </div>
  </div>

  <script>
    function updatePreview() {
      var text = document.getElementById('text-input').value;

      // Créez ici votre requête JSON pour générer le PDF en utilisant la bibliothèque pdfmake
      var docDefinition = {
        content: [
          { text: text, fontSize: 16 }
        ]
      };

      // Génère le PDF et l'affiche dans l'aperçu
      pdfMake.createPdf(docDefinition).getDataUrl(function (dataUrl) {
        document.getElementById('pdf-preview').src = dataUrl;
      });
    }
  </script>
</body>
</html>
