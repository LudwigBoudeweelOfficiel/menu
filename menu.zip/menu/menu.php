<?php
require('fpdf/fpdf.php');

// Vérifiez si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Récupère le texte saisi dans le champ
  $titre = $_POST['Titre'];
  $lundi_entree = $_POST['lun_entree'];
  $lundi_plat = $_POST['lun_plat'];
  $lundi_fromage = $_POST['lun_fromage'];
  $lundi_dessert = $_POST['lun_dessert'];

  // Génère le PDF avec FPDF
  $pdf = new FPDF("L");
  $pdf->AddPage();
  $pdf->SetFont('Arial', '', 12);
  
  
	// ----------------------------------------------- A MODIFIER A PARTIR D'ICI -----------------------------------------------------
	// Titre
	// Personnalisation du contenu (exemple : police, taille, couleur)
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 25, '', 1, 1);
    $pdf->SetTextColor(0, 0, 0);
	// Logo
	$pdf->Image('logo.png',15,15,40);
	
	
    // Décalage à droite
    $pdf->SetFont('Arial', '', 14);
    $pdf->Ln(-24);
    $pdf->Cell(120);
    $pdf->Cell(40, 10, 'LYCEE PROFESSIONNEL GEORGES GUYNEMER', 0, 0, 'C');
    $pdf->Ln(7);
    // Récupérer les coordonnées de la dernière position
    $lastX = $pdf->GetX();
    $lastY = $pdf->GetY();
    $pdf->SetX(120);
    $pdf->Cell(40, 10, utf8_decode('99, Rue de la République'), 0, 0, 'C');
    $pdf->Ln(7);
    // Récupérer les coordonnées de la dernière position
    $lastX = $pdf->GetX();
    $lastY = $pdf->GetY();
    $pdf->SetX(120);
    $pdf->Cell(40, 10, utf8_decode('59430, SAINT POL SUR MER'), 0, 0, 'C');
    $pdf->Ln(18);

    // Affichage du titre du menu
    $pdf->SetFont('Arial', '', 15);
    $pdf->Cell(277, 10, $lundi_entree, 0, 0, 'C');
  
  
  
  
  

  $pdfData = $pdf->Output('', 'S');

  // Envoie le PDF généré en tant que réponse JSON
  header('Content-Type: application/json');
  echo json_encode(array('pdfData' => base64_encode($pdfData)));
  exit;
}
?>