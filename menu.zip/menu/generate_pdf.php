<?php
require('fpdf/fpdf.php');

// Vérifiez si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Récupère le texte saisi dans le champ
  $text = $_POST['text'];

  // Génère le PDF avec FPDF
  $pdf = new FPDF();
  $pdf->AddPage();
  $pdf->SetFont('Arial', '', 12);
  $pdf->Cell(0, 10, $text, 0, 1);
  $pdfData = $pdf->Output('', 'S');

  // Envoie le PDF généré en tant que réponse JSON
  header('Content-Type: application/json');
  echo json_encode(array('pdfData' => base64_encode($pdfData)));
  exit;
}
?>