<!DOCTYPE html>
<html>
<head>
	<title>Interface gestion du menu</title>
	<link rel="stylesheet" href="css/style.css"/>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
	<form id="pdf-form">
		<div class="flex-container">
			<div>
				<h3>Paramètres</h3>
				<input type="text" id="menuTitle" placeholder="Titre du menu" onkeypress="updatePreview()"/><br>
				<label>Libellé Semaine : </label><input type="text" class="inp_date" id="startDate" name="Titre" placeholder="Date de début" onkeypress="updatePreview()"/><br>
				<hr>
				<input type="checkbox" id="entréesCheckbox" name="menuItems" value="entrées" checked onkeypress="updatePreview()">
				<label for="entréesCheckbox">Entrées</label><br>
				<input type="checkbox" id="platsCheckbox" name="menuItems" value="plats" checked onkeypress="updatePreview()">
				<label for="platsCheckbox">Plat chauds</label><br>
				<input type="checkbox" id="garnituresCheckbox" name="menuItems" value="garnitures" checked onkeypress="updatePreview()">
				<label for="garnituresCheckbox">Garnitures</label><br>
				<input type="checkbox" id="dessertsCheckbox" name="menuItems" value="desserts" checked onkeypress="updatePreview()">
				<label for="dessertsCheckbox">Fromage / Produit Laitiers / Desserts</label><br>
				<br>
				<input type="submit" value="Générer PDF" />
			</div>
			<div>
			    <button class="accordion">Lundi</button>
				<div class="panel">
					<div class="lun_entree">
						<input type="text" id="menuTitle" name="lun_entree" placeholder="Entrée" onkeypress="updatePreview()"/><br>
						<input type="text" id="menuTitle" name="lun_plat" placeholder="Plat" onkeypress="updatePreview()"/><br>
						<input type="text" id="menuTitle" name="lun_fromage" placeholder="Fromage" onkeypress="updatePreview()"/><br>
						<input type="text" id="menuTitle" name="lun_dessert" placeholder="Dessert" onkeypress="updatePreview()"/><br>
					</div>
				</div>


<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
</script>
			</div>
				
			<div><iframe id="pdf-preview" width="500" height="600"></iframe></div>  
		</div>
	</form>

	<script>
    $(document).ready(function() {
      $('#pdf-form').submit(function(event) {
        event.preventDefault();

        var formData = $(this).serialize();

        // Envoie la requête AJAX pour générer le PDF
        $.ajax({
          url: 'menu.php',
          type: 'POST',
          data: formData,
          dataType: 'json',
          success: function(response) {
            var pdfData = response.pdfData;
            var pdfUrl = 'data:application/pdf;base64,' + pdfData;
            $('#pdf-preview').attr('src', pdfUrl);
          }
        });
      });
    });
	
	function updatePreview() {
		var formData = $('#pdf-form').serialize();

		// Envoie la requête AJAX pour générer le PDF
		$.ajax({
			url: 'menu.php',
			type: 'POST',
			data: formData,
			dataType: 'json',
			success: function(response) {
				var pdfData = response.pdfData;
				var pdfUrl = 'data:application/pdf;base64,' + pdfData;
				$('#pdf-preview').attr('src', pdfUrl);
			}
		});
	}

	$(document).ready(function() {
		// Charge l'aperçu initial du PDF
		updatePreview();
	});
  </script>
</body>
</html>
