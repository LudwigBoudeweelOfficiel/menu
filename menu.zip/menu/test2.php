

<!DOCTYPE html>
<html>
<head>
  <title>Formulaire PDF</title>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
  <div>
    <h1>Formulaire PDF</h1>
    <form id="pdf-form" method="POST">
      <label for="text-input">Saisissez votre texte :</label>
      <input id="text-input" name="text" type="text" />
      <input type="submit" value="Générer PDF" />
    </form>
    <div>
      <h2>Aperçu du PDF :</h2>
      <iframe id="pdf-preview" width="500" height="600"></iframe>
    </div>
  </div>

  <script>
    $(document).ready(function() {
      $('#pdf-form').submit(function(event) {
        event.preventDefault();

        var formData = $(this).serialize();

        // Envoie la requête AJAX pour générer le PDF
        $.ajax({
          url: 'generate_pdf.php',
          type: 'POST',
          data: formData,
          dataType: 'json',
          success: function(response) {
            var pdfData = response.pdfData;
            var pdfUrl = 'data:application/pdf;base64,' + pdfData;
            $('#pdf-preview').attr('src', pdfUrl);
          }
        });
      });
    });
  </script>
</body>
</html>
